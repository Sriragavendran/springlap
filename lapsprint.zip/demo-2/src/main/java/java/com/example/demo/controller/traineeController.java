package java.com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.trainee;
import com.example.demo.service.traineeServiceImpl;

import java.util.List;

@RestController
@RequestMapping("/trainee")
public class traineeController {
	@Autowired
	traineeServiceImpl service;
	 @GetMapping("/all")//http://localhost:7878/trainee/all
	    public ResponseEntity<List<trainee>> listAll() {
	        List<trainee> list = service.list();
	        return new ResponseEntity<>(list,new HttpHeaders(),HttpStatus.OK);
	       	    }
	 @PostMapping("/create")//http://localhost:7878/create
	    public ResponseEntity<Boolean> create(@RequestBody trainee tr) {
	        tr=service.add(tr);
	        @SuppressWarnings({ "rawtypes", "unchecked" })
			ResponseEntity<Boolean> responseEntity=new ResponseEntity(true,HttpStatus.OK);
	        return responseEntity;
	        	    }
	 @PutMapping("/update")//http://localhost:7878/update
	    public ResponseEntity<Boolean> update(@RequestBody trainee tr) {
	        tr=service.update(tr);
	        @SuppressWarnings({ "rawtypes", "unchecked" })
			ResponseEntity<Boolean> responseEntity=new ResponseEntity(true,HttpStatus.OK);
	        return responseEntity;
	        	    }
	 @DeleteMapping("/delete")
	 public String deleteTrainee(@RequestParam Integer id) {
			service.delete(id);
			return " Deleted";
		}
	 }
	 
	 

