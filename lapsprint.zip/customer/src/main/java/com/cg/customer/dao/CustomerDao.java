package com.cg.customer.dao;

import java.util.List;

import com.cg.customer.entity.Customer;
import com.cg.customer.exceptions.CustomerIdNotFoundException;

public interface CustomerDao {

	 Customer addCustomer(Customer customer);

	 Customer updateCustomer(Customer customer);
	
	 Customer deleteCustomer(int customerId) throws CustomerIdNotFoundException;
	
	 Customer viewCustomer(int customerid)throws CustomerIdNotFoundException;
	
	 List<Customer> viewCustomersList();
	
	 void commitTransaction();

     void beginTransaction();

}
