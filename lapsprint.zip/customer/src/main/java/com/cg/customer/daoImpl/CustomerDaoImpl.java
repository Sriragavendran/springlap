package com.cg.customer.daoImpl;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.customer.dao.CustomerDao;
import com.cg.customer.dao.JPAUtil;
import com.cg.customer.entity.Customer;
import com.cg.customer.exceptions.CustomerIdNotFoundException;

public class CustomerDaoImpl implements CustomerDao {

	private EntityManager entityManager;

	public CustomerDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public Customer addCustomer(Customer customer) {
		entityManager.persist(customer);
		return customer;
	}

	public Customer updateCustomer(Customer customer) {
		entityManager.merge(customer);
		return customer;
	}
	
	public Customer deleteCustomer(int customerId) throws CustomerIdNotFoundException {
		Customer cus = entityManager.find(Customer.class, customerId);
		if(cus == null) {
			throw new CustomerIdNotFoundException("Customer id is wrong");
		}
		entityManager.remove(cus);
		cus = null;
		return cus;
	}

	public Customer viewCustomer(int customerid) throws CustomerIdNotFoundException {
		Customer cus = entityManager.find(Customer.class, customerid);
		if(cus == null) {
			throw new CustomerIdNotFoundException(customerid);
		}
		return cus;
	}

	public List<Customer> viewCustomersList() {
		TypedQuery<Customer> query= entityManager.createQuery("select c from Customer c", Customer.class);
		List<Customer> allCustomers = query.getResultList();
		return allCustomers;
	}


	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}


}
