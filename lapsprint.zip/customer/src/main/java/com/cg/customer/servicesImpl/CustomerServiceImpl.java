package com.cg.customer.servicesImpl;

import java.util.List;

import com.cg.customer.daoImpl.CustomerDaoImpl;
import com.cg.customer.entity.Customer;
import com.cg.customer.exceptions.CustomerIdNotFoundException;
import com.cg.customer.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {

	private CustomerDaoImpl dao;

	public CustomerServiceImpl() {
		dao = new CustomerDaoImpl();
	}

	public Customer addCustomer(Customer customer) {
		dao.beginTransaction();
		dao.addCustomer(customer);
		dao.commitTransaction();
		return customer;
	}

	public Customer updateCustomer(Customer customer) {
		dao.beginTransaction();
		dao.updateCustomer(customer);
		dao.commitTransaction();
		return customer;
	}

	public Customer deleteCustomer(int customerId) {
		Customer cus = null;
		dao.beginTransaction();
		
		try {
			cus = dao.deleteCustomer(customerId);
				
			dao.deleteCustomer(customerId);
		} catch (CustomerIdNotFoundException e) {
			System.out.println(e);
		}
		
		dao.commitTransaction();
		
		return cus;
	}

	public Customer viewCustomer(int customerid) {
		Customer cus = null;
		try {
			cus = dao.viewCustomer(customerid);
		} catch (CustomerIdNotFoundException e) {
			System.out.println(e);
		}
		return cus;
	}

	public List<Customer> viewCustomersList() {
		List<Customer> allCustomers = dao.viewCustomersList();
		return allCustomers;
	
	}
}


