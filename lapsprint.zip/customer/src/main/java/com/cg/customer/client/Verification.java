package com.cg.customer.client;

import java.util.List;

import com.cg.customer.entity.Customer;

public class Verification {



	public boolean checkMobileNumber(String regex, String s, List<Customer> list) {
		long customerMobile=Long.parseLong(s);
		if(s.matches(regex)) {
			boolean flag=true;
			for (Customer num : list) {
				if (num.getCustomerMobile() == customerMobile) {
					flag=false;
					System.out.println("Already exist.. Please Enter different mobile number");
					return false;
				}
			}
			if(flag) {
				return true;
			}
		}
		
		else if(!s.matches(regex)) {
			System.out.println("Enter valid mobile number");
			return false;
		}
		return true;
		
	}

	public boolean checkEmail(String emailRegex, String customerEmail, List<Customer> list) {
		if(customerEmail.matches(emailRegex)) {
			boolean flag=true;
			for (Customer num : list) {
				if (num.getCustomerEmail().equals(customerEmail)) {
					flag=false;
					System.out.println("Already exist.. Please Enter different Email id");
					return false;
				}
			}
			if(flag) {
				return true;
			}
		}
		
		else if(!customerEmail.matches(emailRegex)) {
			System.out.println("Enter valid Email");
			return false;
		}
		return true;
	}


}
