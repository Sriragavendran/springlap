package com.cg.customer.service;

import java.util.List;

import com.cg.customer.entity.Customer;

public interface CustomerService {

	Customer addCustomer(Customer customer);//adding new customer

    Customer updateCustomer(Customer customer);//update the details of existing customer detail
	
	Customer deleteCustomer(int customerId);//delete entire customer detail
	
	Customer viewCustomer(int customerid);// view the details of customer using id
	
	List<Customer> viewCustomersList();//view all customer

}
