package com.cg.customer.client;

import java.util.*;

import com.cg.customer.entity.Customer;
import com.cg.customer.exceptions.CustomerIdNotFoundException;
import com.cg.customer.service.CustomerService;
import com.cg.customer.servicesImpl.CustomerServiceImpl;

public class User {
	static Scanner scan = new Scanner(System.in);
	static CustomerService service = new CustomerServiceImpl();

	public static void addNewUser() {
		List<Customer> list = service.viewCustomersList();

		System.out.println("Start entering the below details");
		System.out.println("Enter the customerName");
		String customerName = scan.next();
		System.out.println("Enter the mobile number");
		long customerMobile = scan.nextLong();
		String s = String.valueOf(customerMobile);
		String regex = "(0/91)?[6-9][0-9]{9}";
		Verification verify = new Verification();
		boolean mobile = verify.checkMobileNumber(regex, s, list);// verification of mobile number
		while (!mobile) {
			s = scan.next();
			mobile = verify.checkMobileNumber(regex, s, list);// verification of mobile number
		}
		System.out.println("Enter the email id");
		String customerEmail = scan.next();
		String emailRegex = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$";
		boolean email = verify.checkEmail(emailRegex, customerEmail, list);// verification of Email
		while (!email) {
			customerEmail = scan.next();
			email = verify.checkEmail(emailRegex, customerEmail, list);// verification of Email
		}
		System.out.println("Enter the Address");
		String customerAddress = scan.next();
		System.out.println("Enter the username (Minimum nameLength 4-6)");
		String userName = scan.next();
		String check = "[a-zA-Z]{4,6}";

		while (!userName.matches(check)) {
			System.out.println("\nInvalid Try newUserName\n");
			userName = scan.next();
		}

		System.out.println(
				"Enter the password(include atleast 1 specialCharacter and 1 number and length should be 8-20)");
		String password = scan.next();

		String passcheck = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,15}";
		while (!password.matches(passcheck)) {
			System.out.println("Password not matches the Constrain");
			System.out.println(
					"Enter the password(include atleast 1 specialCharacter and 1 number and length should be 8-20)");
			password = scan.next();
		}
		Customer customer = new Customer(customerName, customerMobile, customerEmail, customerAddress, userName,
				password);
		service.addCustomer(customer);
		System.out.println("\n\nSave your customer Id \n" + customer.getCustomerId());
		System.out.println("Register Completed");
	}

	public static void signIn() throws CustomerIdNotFoundException {
		System.out.println("Enter the customerId");
		int customerId = scan.nextInt();
		System.out.println("Enter the username");
		String e_userName = scan.next();
		System.out.println("Enter the password");
		String e_password = scan.next();

		try {
			Customer customerLogin = service.viewCustomer(customerId);

			if (customerLogin.getUserName().equals(e_userName) && customerLogin.getPassword().equals(e_password)) {
				System.out.println("Login SuccessFul");
			} else {
				System.out.println("InvalidUserId or name or password");
			}
		} catch (Exception e) {
			throw new CustomerIdNotFoundException("Not registered please create an account");
		}
	}

	public static void forgotPassword() {
		System.out.println("Enter Your UniqueId");
		int passResetId = scan.nextInt();
		Customer passReset = service.viewCustomer(passResetId);

		System.out.println(passReset.getPassword());

		// service.updateCustomer(passReset);

	}

	public static void main(String[] args) throws CustomerIdNotFoundException {

		boolean restart = true;
		while (restart) {
			System.out.println("Select the option");
			System.out.println("1)New User Registration");
			System.out.println("2)Sign in(Existing user)");
			System.out.println("3)Forgot Password");
			System.out.println("4)ViewCustomers(ADMIN)");
			System.out.println("5)Delete Customer(ADMIN)");
			System.out.println("6)Sign Out");
			int option = scan.nextInt();
			switch (option) {
			case 1:
				addNewUser();// adding new user
				break;
			case 2:
				signIn();// Login purpose
				break;
			case 3:
				forgotPassword();// Find the password using id only
				break;
			case 4:
				System.out.println("Enter the Admin password to view customer List");
				if (scan.next().equals("Admin@123")) {
					List<Customer> list = service.viewCustomersList();
					if (list.equals(null))
						System.out.println("No customer Found");
					for (Customer obj : list) {
						System.out.print(obj.getCustomerId() + " ");
						System.out.print(obj.getCustomerName() + " ");
						System.out.print(obj.getCustomerEmail() + " ");
						System.out.print(obj.getCustomerAddress() + " ");
						System.out.println();
						// System.out.print(obj.getUserName() + " \n");
					}
				} else
					System.out.println("Invalid password");
				break;
			case 5:
				System.out.println("Enter the Admin password to view customer List");
				if (scan.next().equals("Admin@123")) {
					System.out.println("Enter the CustomerId to be deleted");
					int deltId = scan.nextInt();
					service.deleteCustomer(deltId);
				} else
					System.out.println("Invalid password");
				break;

			case 6:
				System.out.println("Thank you for using our application");
				restart = false;
				break;

			}
		}
		System.out.println("Do you want to continue? type yes/no");
		String process = scan.next();
		if (process.equalsIgnoreCase(process))
			restart = true;
		else
			restart = false;

	}
}
