package com.onlinepizza.service;

public class AdminServiceImpl {

}
