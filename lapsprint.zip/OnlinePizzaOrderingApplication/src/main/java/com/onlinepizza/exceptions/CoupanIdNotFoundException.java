package com.onlinepizza.exceptions;

public class CoupanIdNotFoundException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public CoupanIdNotFoundException(String message) {
	super(message);
}
}
