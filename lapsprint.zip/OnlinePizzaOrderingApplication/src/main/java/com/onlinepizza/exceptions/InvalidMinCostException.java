package com.onlinepizza.exceptions;

public class InvalidMinCostException extends Exception {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;

	public InvalidMinCostException(String message) {
		super(message);
	}
}
