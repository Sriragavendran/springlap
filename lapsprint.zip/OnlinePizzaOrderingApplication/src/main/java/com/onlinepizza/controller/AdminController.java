package com.onlinepizza.controller;

public class AdminController {

}
