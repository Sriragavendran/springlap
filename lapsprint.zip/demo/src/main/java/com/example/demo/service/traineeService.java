package com.example.demo.service;

import java.util.*;

import com.example.demo.entity.trainee;

public interface traineeService {
	public trainee add(trainee trainee1);

	List<trainee> list();

	public trainee update(trainee trainee1);

	public void delete(int id);
}
