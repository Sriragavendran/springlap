package com.example.demo.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.trainee;
@Repository
public class traineeDaoImpl implements traineeDao{
@PersistenceContext
private EntityManager e_man;
	@Override
	public trainee add(trainee trainee1) {
		e_man.persist(trainee1);
		return trainee1;
	}

	@Override
	public List<trainee> list() {
		 CriteriaQuery<trainee> criteriaQuery = e_man.getCriteriaBuilder().createQuery(trainee.class);
	      @SuppressWarnings("unused")
	      Root<trainee> root = criteriaQuery.from(trainee.class);
	      return e_man.createQuery(criteriaQuery).getResultList();

	}

	public trainee update(trainee trainee1) {
		e_man.merge(trainee1);
		return trainee1;
	}
	public void delete(int id) {
		trainee tr=e_man.find(trainee.class, id);
		e_man.remove(e_man.merge(tr));
		
	}

	
}
