package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.trainee;

public interface traineeDao {
	public trainee add(trainee trainee1);

	List<trainee> list();

	public trainee update(trainee trainee1);

	public void delete(int id);
}
