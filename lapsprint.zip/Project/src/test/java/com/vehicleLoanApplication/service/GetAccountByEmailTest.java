package com.vehicleLoanApplication.service;

 


//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertNotNull;
//import static org.junit.Assert.assertNull;
//import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

 

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

 

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

 

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;
import com.vehicleloanapplication.dao.AccountJPARepository;
import com.vehicleloanapplication.dao.LoanApplicationJPARepository;
import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.AccountEntity;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.AccountServiceImpl;
import com.vehicleloanapplication.service.UserDetailsServiceImpl;

 


@SpringBootTest
public class GetAccountByEmailTest {

 

    @BeforeEach
    public void setup() {
        

 

    }
    @MockBean
    AccountJPARepository accountRepo;
    @MockBean
    UserRegisterJPARepository userRegisterRepo;
    @Autowired
    AccountServiceImpl Service;
    //ADDING USER DETAILS BY EMAIL
    @Test
    @DisplayName("Test - show User details by email - successful")
    public void correctObjectPassed(){
        String email = "hello@gmail.com";
        UserDetailsEntity user=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
        UserRegistrationEntity userRegistration=new UserRegistrationEntity("hello@gmail.com",22,"Female","7799854820", "RubyElite", "HTER3456",user);
        AccountEntity accountEntity = new AccountEntity(123,user);
        
        AccountEntity acc = new AccountEntity();    
        Mockito.when(accountRepo.getByEmail(email)).thenReturn(accountEntity);
        try {
            acc=Service.getAccountByEmail(email);
            
        } catch (RecordNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        assertEquals(accountEntity,acc);

 

    }
    //NO EMAIL ENTERED
    @Test
    @DisplayName("Show User details by email- no email entered")
    public void nullEmailEntered(){
        String email = null;
        UserDetailsEntity user=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
        UserRegistrationEntity userRegistration=new UserRegistrationEntity("hello@gmail.com",22,"Female","7799854820", "RubyElite", "HTER3456",user);
        AccountEntity accountEntity = new AccountEntity(123,user);
        
        AccountEntity acc = new AccountEntity();    
        Mockito.when(accountRepo.getByEmail(email)).thenReturn(accountEntity);
        try {
            acc=Service.getAccountByEmail(email);
            
        } catch (RecordNotFoundException e) {
            assertNull(acc);
            // TODO Auto-generated catch block
            e.printStackTrace();
            assertEquals(e.getMessage(),"Record doesn't exist");
        }
        
    }
    
}


 

 

 

 

 

 

 

 

 

 

 

