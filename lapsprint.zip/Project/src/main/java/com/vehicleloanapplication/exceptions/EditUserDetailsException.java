package com.vehicleloanapplication.exceptions;

public class EditUserDetailsException extends Exception{
	public EditUserDetailsException(String msg) {
		super(msg);
	}

}
