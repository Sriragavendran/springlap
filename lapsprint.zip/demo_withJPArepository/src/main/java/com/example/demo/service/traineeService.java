package com.example.demo.service;

import com.example.demo.entity.trainee;
public interface traineeService {
public trainee add(trainee trainee1);
Iterable<trainee> list();
public trainee update(trainee trainee1);
public void delete(int id);
}
