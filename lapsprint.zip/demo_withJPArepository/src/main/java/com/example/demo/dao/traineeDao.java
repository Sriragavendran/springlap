package com.example.demo.dao;

import com.example.demo.entity.trainee;


import org.springframework.data.jpa.repository.JpaRepository;

public interface traineeDao extends JpaRepository<trainee,Integer> {

//	@SuppressWarnings("unchecked")
//	trainee save(trainee trainee1);
	//public trainee update(trainee trainee1);
//public trainee add(trainee trainee1) {
//	
//}
//List<trainee> list();

//public void delete(int id);
}
