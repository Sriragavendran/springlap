package com.example.demo.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.traineeDao;
import com.example.demo.entity.trainee;
@Service
@Transactional
public class traineeServiceImpl implements traineeService{

	@Autowired
	private traineeDao dao;
	
//	@Override
//	public trainee add(trainee trainee1) {
//				return dao.add(trainee1);
//	}
// 
//	@Override
//	public List<trainee> list() {
//			return dao.list();
//	}
//	
@Override
public trainee update(trainee trainee1) {
	return dao.save(trainee1);
}

	@Override
 public trainee add(trainee trainee1) {
	 return dao.save(trainee1);
 }

	@Override
	public Iterable<trainee> list() {
		return dao.findAll();
	}

	

	@Override
	public void delete(int id) {
		dao.deleteById(id);
		
	}
}
