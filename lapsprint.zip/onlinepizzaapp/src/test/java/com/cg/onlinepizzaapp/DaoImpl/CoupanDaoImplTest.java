package com.cg.onlinepizzaapp.DaoImpl;


import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.exceptions.CoupanIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.InvalidCoupanOperationException;

import junit.framework.TestCase;

class CoupanDaoImplTest extends TestCase {
      CoupanDaoImpl couDao;
      
	@BeforeEach
	protected void setUp() throws Exception {
		couDao = new CoupanDaoImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		couDao = null;
	}

	@Test
	public void testCoupanDaoImpl() {
		assertTrue(couDao instanceof CoupanDaoImpl);
	}

	@Test
	public void testAddCoupans() {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		couDao.beginTransaction();
		Coupan c=couDao.addCoupans(cou);
		couDao.commitTransaction();
		assertEquals(c.getCoupanName(),"ExtraFifty");	
	}

	@Test
	public void testDeleteCoupans() throws CoupanIdNotFoundException {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		couDao.beginTransaction();
		cou = couDao.addCoupans(cou);
		cou = couDao.deleteCoupans(cou.getCoupanId());
		couDao.commitTransaction();
		assertNull(cou);
	}

	@Test
	public void testEditCoupans() throws InvalidCoupanOperationException {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		couDao.beginTransaction();
		cou = couDao.addCoupans(cou);
		couDao.commitTransaction();
		
		cou.setCoupanType("Buy1 & Get1");
		
		couDao.beginTransaction();
		cou = couDao.editCoupans(cou);
		couDao.commitTransaction();
		assertEquals(cou.getCoupanType(), "Buy1 & Get1");	
		
	}

	@Test
	public void testViewCoupans() {
		List<Coupan> couList = couDao.viewCoupans();
		assertNotNull(couList);
	}

}
