package com.cg.onlinepizzaapp.DaoImpl;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.InvalidMinCostException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;

import java.util.*;
import junit.framework.TestCase;
class PizzaDaoImplTest extends TestCase {
 PizzaDaoImpl pizDao;
	@BeforeEach
	protected void setUp() throws Exception {
		pizDao=new PizzaDaoImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		pizDao=null;
	}

	@Test
	public void testPizzaDaoImpl() {
	assertTrue(pizDao instanceof PizzaDaoImpl);
	}

	@Test
	public void testFindPizzaById() {
		Pizza newPizz=new Pizza("Medium","CheeseBurst","Vegetarian",200,100);
		pizDao.beginTransaction();
		Pizza np=pizDao.addPizza(newPizz);
		pizDao.commitTransaction();
		assertEquals(np.getPizzaType(),"Medium");
	}

	@Test
	void testDeletePizzaPizza() throws PizzaIdNotFoundException {
		Pizza np=new Pizza("Medium","CheeseBurst","Vegetarian",200,100);
		pizDao.beginTransaction();
		 np=pizDao.addPizza(np);
		np=pizDao.deletePizza(np.getPizzaId());
		pizDao.commitTransaction();
		assertNull(np);
	}

	@Test
	void testViewPizzaPizza() {
		Pizza newPizz=new Pizza("Medium","CheeseBurst","Vegetarian",200,100);
		pizDao.beginTransaction();
		Pizza np=pizDao.addPizza(newPizz);
		List<Pizza> pizList= pizDao.viewPizzaList(np);
		pizDao.commitTransaction();
		assertNotNull(pizList);
		
	}
	@Test
	void testViewPizzaString () {
		Pizza newPizz=new Pizza("Medium","CheeseBurst","Vegetarian",200,100);
		pizDao.beginTransaction();
		Pizza np=pizDao.addPizza(newPizz);
		List<Pizza> pizList= pizDao.viewPizzaList(np.getPizzaType());
		pizDao.commitTransaction();
		assertNotNull(pizList);
	}
	void testViewPizzaCost () throws InvalidMinCostException {
		Pizza newPizz=new Pizza("Medium","CheeseBurst","Vegetarian",200,100);
		pizDao.beginTransaction();
	newPizz=pizDao.addPizza(newPizz);
		List<Pizza> pizList= pizDao.viewPizzaList(100,300);
		pizDao.commitTransaction();
		assertNotNull(pizList);
	}
}
