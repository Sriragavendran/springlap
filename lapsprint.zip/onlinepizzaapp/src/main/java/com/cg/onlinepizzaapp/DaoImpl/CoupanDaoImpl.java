package com.cg.onlinepizzaapp.DaoImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.onlinepizzaapp.dao.CoupanDao;
import com.cg.onlinepizzaapp.dao.JPAUtil;
import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.exceptions.CoupanIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.InvalidCoupanOperationException;

public class CoupanDaoImpl implements CoupanDao {

	private EntityManager entityManager;

	public CoupanDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public Coupan addCoupans(Coupan coupan) {
		entityManager.persist(coupan);
		return coupan;
	}

	public Coupan editCoupans(Coupan coupan) throws InvalidCoupanOperationException {
		Coupan cou = entityManager.find(Coupan.class, coupan.getCoupanId());
		if(cou == null) {
			throw new InvalidCoupanOperationException();
		}
		entityManager.merge(cou);
		return cou;
	}
	
	public Coupan deleteCoupans(int coupanId) throws CoupanIdNotFoundException {
		Coupan cou = entityManager.find(Coupan.class, coupanId);
		if(cou == null) {
			throw new CoupanIdNotFoundException(coupanId);
		}
		entityManager.remove(cou);
		cou = null;
		return cou;
	}


	public List<Coupan> viewCoupans() {
		TypedQuery<Coupan> query= entityManager.createQuery("select C from Coupan C", Coupan.class);
		List<Coupan> allCoupans = query.getResultList();
		return allCoupans; 
	}
	
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}



}
