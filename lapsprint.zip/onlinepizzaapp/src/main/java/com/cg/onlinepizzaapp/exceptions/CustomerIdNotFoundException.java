package com.cg.onlinepizzaapp.exceptions;

public class CustomerIdNotFoundException extends Exception {
	public CustomerIdNotFoundException(int customerId) {
		System.out.println(customerId + " Not Found");	
	}

	public CustomerIdNotFoundException(String message){
		super(message);
		
	}

}
