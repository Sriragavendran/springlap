package com.cg.onlinepizzaapp.service;

import com.cg.onlinepizzaapp.entity.Pizza;

import java.util.*;

public interface PizzaService {

    Pizza addPizza(Pizza pizza);
    
    Pizza updatePizza(Pizza pizza);

    Pizza deletePizza(Pizza pizza);
    
	List<Pizza> viewPizzaList(Pizza pizza);
	
    List<Pizza> viewPizza(Integer pizzaId);
    
	List<Pizza> viewPizzaList(double minCost,double maxCost);
	
	List<Pizza> viewPizzaList(String pizzaType);

}
