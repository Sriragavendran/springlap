package com.cg.onlinepizzaapp.ServiceImpl;

import java.util.List;

import com.cg.onlinepizzaapp.DaoImpl.CoupanDaoImpl;
import com.cg.onlinepizzaapp.dao.CoupanDao;
import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.exceptions.CoupanIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.InvalidCoupanOperationException;
import com.cg.onlinepizzaapp.service.CoupanService;

public class CoupanServiceImpl implements CoupanService {

	private CoupanDao dao;

	public CoupanServiceImpl() {
		dao = new CoupanDaoImpl();
	}

	public Coupan addCoupans(Coupan coupan) {
		dao.beginTransaction();
		dao.addCoupans(coupan);
		dao.commitTransaction();
		return coupan;
	}

	public Coupan editCoupans(Coupan coupan) {
		Coupan cou = null;
		dao.beginTransaction();
		
		try {
			cou = dao.editCoupans(coupan);
				
			dao.editCoupans(coupan);
		} catch (InvalidCoupanOperationException e) {
			System.out.println(e);
		}
		
		dao.commitTransaction();
		
		return cou;
	}

	public Coupan deleteCoupans(int coupanId) {
		Coupan cou = null;
		dao.beginTransaction();
		
		try {
			cou = dao.deleteCoupans(coupanId);
				
			dao.deleteCoupans(coupanId);
		} catch (CoupanIdNotFoundException e) {
			System.out.println(e);
		}
		
		dao.commitTransaction();
		
		return cou;
	}

	public List<Coupan> viewCoupans() {
		List<Coupan> allCoupans = dao.viewCoupans();
		return allCoupans;
	
	}

}
