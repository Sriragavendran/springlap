package com.cg.onlinepizzaapp.client;
import java.util.List;
import java.util.Scanner;

import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.service.CoupanService;
import com.cg.onlinepizzaapp.ServiceImpl.CoupanServiceImpl;

public class CoupanAdmin {

	public static void main(String[] args) {
		CoupanService service = new CoupanServiceImpl();
		Coupan coupan = new Coupan();
		int coupanId;
		String coupanName;
		String coupanType;
		String coupanDescription;
		int coupanPizzaId;
		
		int temp = 0;
		while (temp==0) {
			Scanner s = new Scanner(System.in);
			System.out.println("\n");
			System.out.println("****Coupan Service****");
			System.out.println("1.Add Coupan");
			System.out.println("2.Edit Coupan");
			System.out.println("3.Delete Coupan");
			System.out.println("4.View Coupans");
			System.out.println("5.Exit");
			System.out.println("Enter choice:");
			int choice = s.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter Coupan Id:");
				coupanId = s.nextInt();
				System.out.println("Enter Coupan Name:");
				coupanName = s.next();
				System.out.println("Enter Coupan Type:");
				coupanType = s.next();
				System.out.println("Enter Coupan Description:");
				coupanDescription = s.next();
				System.out.println("Enter Coupan Pizza Id:");
				coupanPizzaId = s.nextInt();
				
				coupan.setCoupanId(coupanId);
				coupan.setCoupanName(coupanName);
				coupan.setCoupanType(coupanType);
				coupan.setCoupanDescription(coupanDescription);
				coupan.setCoupanPizzaId(coupanPizzaId);
				service.addCoupans(coupan);
				
				System.out.println("Added Successfully");

				break;

			
//			case 3:
//				System.out.println("Enter Coupan Id to Delete");
//				coupanId = s.nextInt();
//				coupan = service.findCoupanById(coupanId);
//				if (coupan != null) {
//					service.deleteCoupan(coupan);
//					System.out.println("Deleted Successfully");
//				} 
//				else
//					System.out.println("Coupan Id not found"); 
//
//				break;

			case 4:
				List<Coupan> list=service.viewCoupans();
				for(Coupan l:list)
				System.out.println(l);
				
				break;

			case 5:
				temp = 1;
				System.out.println("Terminated");
				break;

			default:
				System.out.println("Invalid choice");
				break;		
			}
		}
		


	}

}
