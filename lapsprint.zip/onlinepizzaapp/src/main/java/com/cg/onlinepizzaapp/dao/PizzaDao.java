package com.cg.onlinepizzaapp.dao;

import java.util.List;

import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.InvalidMinCostException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;

public interface PizzaDao {

	Pizza addPizza(Pizza pizza);
	
	Pizza updatePizza(Pizza pizza);

	Pizza deletePizza(Integer pizzaId) throws PizzaIdNotFoundException; 

	List<Pizza> viewPizzaList(Pizza pizza);

	List<Pizza> viewPizza(Integer PizzaId) throws PizzaIdNotFoundException;

	List<Pizza> viewPizzaList(double minCost, double maxCost) throws InvalidMinCostException;
	
	List<Pizza> viewPizzaList(String pizzaType);

	public void beginTransaction();

	public void commitTransaction();
}
