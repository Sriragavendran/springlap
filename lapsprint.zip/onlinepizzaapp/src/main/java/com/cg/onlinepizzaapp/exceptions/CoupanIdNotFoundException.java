package com.cg.onlinepizzaapp.exceptions;

import com.cg.onlinepizzaapp.entity.Coupan;

public class CoupanIdNotFoundException extends Exception {
public CoupanIdNotFoundException(int coupanId) {
	System.out.println(coupanId + " Not Found");
}
public CoupanIdNotFoundException(String message) {
	super(message);
}
public CoupanIdNotFoundException(Coupan coupan) {
	System.out.println(coupan + " Not Found");
	
}
}
