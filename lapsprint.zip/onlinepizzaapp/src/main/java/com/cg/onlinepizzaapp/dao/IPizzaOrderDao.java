package com.cg.onlinepizzaapp.dao;

import java.time.LocalDate;
import java.util.List;

import com.cg.onlinepizzaapp.entity.PizzaOrder;

public interface IPizzaOrderDao {

	public PizzaOrder bookPizzaOrder(PizzaOrder order);
	
	public void updatePizzaOrder(PizzaOrder order);

	public void cancelPizzaOrder(Integer bookingOrderId);

	public List<PizzaOrder> viewOrdersList(PizzaOrder order);

	public List<PizzaOrder> viewOrdersList(LocalDate date);

	public PizzaOrder viewPizzaOrder(Integer bookingOrderId);
	
	public List<PizzaOrder> calculateTotal(String size, Integer quantity);

	public  void beginTransaction();

	public void commitTransaction();
}
