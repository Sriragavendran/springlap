package com.cg.onlinepizzaapp.exceptions;

public class PizzaIdNotFoundException extends Exception {
	public PizzaIdNotFoundException(int pizzaId) {
		// TODO Auto-generated constructor stub
		System.out.println(pizzaId+"Not found");
	}

	public PizzaIdNotFoundException(String message) {
		super(message);
	}
}
