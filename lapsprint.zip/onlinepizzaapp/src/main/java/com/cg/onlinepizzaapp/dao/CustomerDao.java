package com.cg.onlinepizzaapp.dao;

import java.util.List;


import com.cg.onlinepizzaapp.entity.Customer;

import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;

public interface CustomerDao {

	public abstract Customer findCustomerById(int id);

	 Customer addCustomer(Customer customer);

	 Customer updateCustomer(Customer customer);
	
	 Customer deleteCustomer(int customerId) throws CustomerIdNotFoundException;
	
	 Customer viewCustomer(int customerid)throws CustomerIdNotFoundException;
	
	 List<Customer> viewCustomersList();
	
	 void commitTransaction();

     void beginTransaction();

}
