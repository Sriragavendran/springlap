package com.cg.onlinepizzaapp.dao;

import java.util.List;

import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.exceptions.CoupanIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.InvalidCoupanOperationException;

public interface CoupanDao {

	Coupan addCoupans(Coupan coupan);

	Coupan editCoupans(Coupan coupan) throws InvalidCoupanOperationException;

	Coupan deleteCoupans(int coupanId) throws CoupanIdNotFoundException;
	
	List<Coupan> viewCoupans();

	void commitTransaction();

	void beginTransaction();

}