package com.cg.onlinepizzaapp.service;

import java.time.LocalDate;
import java.util.List;

import com.cg.onlinepizzaapp.entity.PizzaOrder;

public interface IPizzaOrderService {

		//public abstract  PizzaOrder findPizzaOrderById(int id);
		public abstract  void bookPizzaOrder(PizzaOrder order);
		public abstract void updatePizzaOrder(PizzaOrder order);
		public abstract void cancelPizzaOrder(Integer bookingOrderId);
		public PizzaOrder  viewPizzaOrder(Integer bookingOrderId);
		public abstract List<PizzaOrder> viewOrdersList(PizzaOrder order);
		public abstract List<PizzaOrder> viewOrdersList(LocalDate date);
		public abstract List<PizzaOrder> calculateTotal(String size, Integer quantity);
	}
