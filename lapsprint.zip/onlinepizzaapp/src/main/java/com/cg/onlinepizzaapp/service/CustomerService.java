package com.cg.onlinepizzaapp.service;

import java.util.List;

import com.cg.onlinepizzaapp.entity.Customer;

public interface CustomerService {

	Customer addCustomer(Customer customer);

    Customer updateCustomer(Customer customer);
	
	Customer deleteCustomer(int customerId);
	
	Customer viewCustomer(int customerid);
	
	List<Customer> viewCustomersList();

}
