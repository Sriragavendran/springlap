package com.cg.onlinepizzaapp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PizzaOrder")
public class PizzaOrder {
	@Id
	private int bookingOrderId;
	private String Size;
	private int quantity;
	private double totalCost;
	private String transactionMode;
	//private Pizza pizza;
	//private Order order;
	//private Coupan coupon;
	
	public PizzaOrder(int BookingOrderId, String transactionMode, String Size,  double totalCost,int quantity)
	 {
		super();
		this.bookingOrderId = bookingOrderId;
		this.Size = Size;
		this.quantity = quantity;
		this.totalCost = totalCost;
		this.transactionMode = transactionMode;
		//this.order=order;
		//this.coupon=coupon;
		//this.pizza=pizza;
		
	}

	public PizzaOrder() {
		// TODO Auto-generated constructor stub
	}

	public int getBookingOrderId() {
		return bookingOrderId;
	}

	public void setBookingOrderId(int bookingOrderId) {
		this.bookingOrderId = bookingOrderId;
	}

	public String getSize() {
		return Size;
	}

	public void setSize(String size) {
		Size = size;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(double totalCost) {
		this.totalCost = totalCost;
	}

	public String getTransactionMode() {
		return transactionMode;
	}

	public void setTransactionMode(String transactionMode) {
		this.transactionMode = transactionMode;
	}


	//public Pizza getPizza() {
	//	return pizza;
	//}
//
	//public void setPizza(Pizza pizza) {
	//	this.pizza = pizza;
	//}

	//public Order getOrder() {
	//	return order;
	//}

	//public void setOrder(Order order) {
	//	this.order = order;
	//}

	//public Coupon getCoupon() {
	//	return coupon;
	//}

	//public void setCoupon(Coupon coupon) {
	//	this.coupon = coupon;
	//}

	@Override
	public String toString() {
		return "PizzaOrder [bookingOrderId=" + bookingOrderId + ", transactionMode=" + transactionMode + ", Size="
				+ Size + ", quantity=" + quantity + ", totalCost=" + totalCost + "]";
	}
	
}
