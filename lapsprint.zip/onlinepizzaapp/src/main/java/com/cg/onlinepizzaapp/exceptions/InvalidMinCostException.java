package com.cg.onlinepizzaapp.exceptions;

public class InvalidMinCostException extends Exception {
public InvalidMinCostException(double mincost) {
	System.out.println(mincost+"INVALID Cost");
	// TODO Auto-generated constructor stub
}
public InvalidMinCostException(String message) {
	super(message);
}
}
