package com.cg.onlinepizzaapp.ServiceImpl;

import java.util.List;

import com.cg.onlinepizzaapp.DaoImpl.PizzaDaoImpl;
import com.cg.onlinepizzaapp.dao.PizzaDao;
import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;
import com.cg.onlinepizzaapp.service.PizzaService;

public class PizzaServiceImpl implements PizzaService {
 private PizzaDao dao;
 
	public PizzaServiceImpl() {
	dao= new PizzaDaoImpl();
}
    @Override
	public Pizza addPizza(Pizza pizza) {
		dao.beginTransaction();
		dao.addPizza(pizza);
		dao.commitTransaction();
		return pizza;
	}
    
	public Pizza updatePizza(Pizza pizza) {
		dao.beginTransaction();
		dao.updatePizza(pizza);
		dao.commitTransaction();
		return pizza;
	}
	
	public Pizza deletePizza(Integer pizzaId) {
		Pizza piz = null;
		dao.beginTransaction();
		
		try {
			piz = dao.deletePizza(pizzaId);
				
			dao.deletePizza(pizzaId);
		} catch (PizzaIdNotFoundException e) {
			System.out.println(e);
		}
		
		dao.commitTransaction();
		
		return piz;
	}

//	public List<Pizza> viewPizza(Pizza pizza) {
//	List<Pizza> pizzaList= dao.viewPizza(pizza);
//	return pizzaList;
//	}
//
//	public List<Pizza> viewPizza(String pizzaType) {
//		List<Pizza> pizzaList= dao.viewPizza(pizzaType);
//		return pizzaList;
//	}

//	public List<Pizza> viewPizza(double minCost, double maxCost) {
//		List<Pizza> pizzaList= dao.viewPizza(minCost,maxCost);
//		return pizzaList;
//	}

	@Override
	public List<Pizza> viewPizzaList(Pizza pizza) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pizza> viewPizza(Integer pizzaId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pizza> viewPizzaList(double minCost, double maxCost) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Pizza> viewPizzaList(String pizzaType) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Pizza deletePizza(Pizza pizza) {
		// TODO Auto-generated method stub
		return null;
	}

}
