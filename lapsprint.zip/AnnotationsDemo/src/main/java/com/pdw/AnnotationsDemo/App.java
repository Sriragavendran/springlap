package com.pdw.AnnotationsDemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		Employee emp = (Employee) context.getBean("employee", Employee.class);
		emp.display();
	}
}
//layered architecture @component /@Entity   @Service @Repository

//@Autowired,@Component ,@Configration,@Value,@ComponentScan

			//@Service  @Repository

