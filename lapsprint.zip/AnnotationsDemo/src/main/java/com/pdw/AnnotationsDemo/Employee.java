package com.pdw.AnnotationsDemo;

import org.springframework.beans.factory.annotation.Autowired;

//@Component//Employee employee=new Employee() <bean class=""  id="">
public class Employee {
	private int eid;
	private String ename;
	@Autowired
	private Address add;
	@Autowired
	private TAddress tadd;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	public Employee(int eid, String ename, Address add, TAddress tadd) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.add = add;
		this.tadd = tadd;
	}
	public void display() {
		System.out.println(" " + eid + " " + ename + " " + add + " " + tadd);
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public Address getAdd() {
		return add;
	}

	public void setAdd(Address add) {
		this.add = add;
	}

	public TAddress getTadd() {
		return tadd;
	}

	public void setTadd(TAddress tadd) {
		this.tadd = tadd;
	}
}
