package com.pdw.AnnotationsDemo;

public class TAddress {

	private int hno;
	private String colony;
	private String village;

	public TAddress() {
		// TODO Auto-generated constructor stub
	}

	public TAddress(int hno, String colony, String village) {
		super();
		this.hno = hno;
		this.colony = colony;
		this.village = village;
	}

	public int getHno() {
		return hno;
	}

	public void setHno(int hno) {
		this.hno = hno;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	@Override
	public String toString() {
		return "TAddress [hno=" + hno + ", colony=" + colony + ", village=" + village + "]";
	}

}
