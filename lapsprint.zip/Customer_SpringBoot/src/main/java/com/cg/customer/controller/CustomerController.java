package com.cg.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.customer.entity.Customer;
import com.cg.customer.service.CustomerServiceImpl;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	CustomerServiceImpl service;

	@PostMapping("/create") // http://localhost:7575/create
	public ResponseEntity<Boolean> addCustomer(@RequestBody Customer customer) {
		customer = service.addCustomer(customer);

		ResponseEntity<Boolean> responseEntity = new ResponseEntity<Boolean>(true, HttpStatus.OK);
		return responseEntity;
	}

	@PutMapping("/update") // http://localhost:7575/customer/update
	public ResponseEntity<String> updateCustomer(@RequestBody Customer customer) {
		customer = service.updateCustomer(customer);

		ResponseEntity<String> responseEntity = new ResponseEntity<String>("Details Updated SuccesFully",
				HttpStatus.OK);
		return responseEntity;
	}

	@DeleteMapping("/delete")
	public String deleteCustomer(@RequestParam Integer id) {
		service.deleteCustomer(id);
		return " Deleted SuccessFully";
	}

	@GetMapping("/all") // http://localhost:7575/customer/all
	public ResponseEntity<Iterable<Customer>> listAll() {
		Iterable<Customer> list = service.viewCustomersList();
		return new ResponseEntity<>(list, new HttpHeaders(), HttpStatus.OK);
	}

	

}
