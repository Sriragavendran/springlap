package com.cg.customer.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.customer.dao.CustomerDao;
import com.cg.customer.entity.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService{

	@Autowired
	private CustomerDao dao;

	@Override
	public Customer addCustomer(Customer customer) {
		return dao.save(customer);
	}

	@Override
	public Iterable<Customer> viewCustomersList() {
		return dao.findAll();
	}

	@Override
	public Customer updateCustomer(Customer customer) {
		return dao.save(customer);
	}

	
	public void deleteCustomer(Integer id) {
		dao.deleteById(id);
		
	}

	
	
	
	

	
	

}
