package com.cg.customer.service;

import com.cg.customer.entity.Customer;

public interface CustomerService {
	public Customer addCustomer(Customer customer);

	Iterable<Customer> viewCustomersList();

	public Customer updateCustomer(Customer customer);

	void deleteCustomer(Integer id);
}
