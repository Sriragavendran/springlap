package com.onlinepizza.exceptions;

public class InvalidMinCostMaxCostException extends RuntimeException {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public InvalidMinCostMaxCostException(String message) {
	super(message);
}
}
