package com.onlinepizza.exceptions;



public class CoupanIdNotFoundException extends RuntimeException {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public CoupanIdNotFoundException(String message) {
	super(message);
}

}
