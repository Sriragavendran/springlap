package com.cg.onlinepizzaapp.ServiceImpl;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;

import java.util.*;
import junit.framework.TestCase;

class PizzaServiceImplTest extends TestCase {
	PizzaServiceImpl service;

	@BeforeEach
	protected void setUp() throws Exception {
		service = new PizzaServiceImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		service = null;
	}

	@Test
	public void testPizzaServiceImpl() {
		assertTrue(service instanceof PizzaServiceImpl);
	}

	@Test
	public void testFindPizzaById() {
		Pizza newPizz = new Pizza("Medium", "CheeseBurst", "Vegetarian", 200, 100);
		Pizza np = service.addPizza(newPizz);

		assertEquals(np.getPizzaType(), "Medium");
	}

	@Test
	void testDeletePizzaPizza() throws PizzaIdNotFoundException {
		Pizza np = new Pizza("Medium", "CheeseBurst", "Vegetarian", 200, 100);

		np = service.addPizza(np);
		np = service.deletePizza(np.getPizzaId());

		assertNull(np);
	}

	@Test
	void testViewPizzaPizza() {
		Pizza newPizz = new Pizza("Medium", "CheeseBurst", "Vegetarian", 200, 100);

		newPizz = service.addPizza(newPizz);
		List<Pizza> pizList = service.viewPizzaList();

		assertNotNull(pizList);

	}

	@Test
	void testViewPizzaString() {
		Pizza newPizz = new Pizza("Medium", "CheeseBurst", "Vegetarian", 200, 100);

		Pizza np = service.addPizza(newPizz);
		List<Pizza> pizList = service.viewPizza(np.getPizzaType());

		assertNotNull(pizList);
	}

}
