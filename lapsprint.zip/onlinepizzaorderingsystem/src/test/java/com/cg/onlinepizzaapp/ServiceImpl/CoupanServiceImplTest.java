package com.cg.onlinepizzaapp.ServiceImpl;



import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.onlinepizzaapp.entity.Coupan;


import junit.framework.TestCase;

class CoupanServiceImplTest extends TestCase {
      CoupanServiceImpl service;
      
	@BeforeEach
	protected void setUp() throws Exception {
		service = new CoupanServiceImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		service = null;
	}

	@Test
	void testCoupanServiceImpl() {
	    assertTrue(service instanceof CoupanServiceImpl);
	}

	@Test
	void testAddCoupans() {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		cou = service.addCoupans(cou);
		assertEquals(cou.getCoupanType(), "Discount");
	}

	@Test
	void testEditCoupans() {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		service.addCoupans(cou);
		cou.setCoupanType("Buy1 & Get1");
		cou = service.editCoupans(cou);
		assertEquals(cou.getCoupanType(), "Buy1 & Get1");
	}

	@Test
	void testDeleteCoupans() {
		Coupan cou = new Coupan("ExtraFifty","Discount","Reduces50% of bill");
		cou =service.deleteCoupans(cou.getCoupanId());
		assertNull(cou);
	}

	@Test
	void testViewCoupans() {
		List<Coupan> coup = service.viewCoupans();
		assertNotNull(coup);
	}

}
