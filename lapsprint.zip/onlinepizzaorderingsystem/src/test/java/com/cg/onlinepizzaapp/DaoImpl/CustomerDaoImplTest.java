package com.cg.onlinepizzaapp.DaoImpl;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;

import junit.framework.TestCase;

class CustomerDaoImplTest extends TestCase {
      CustomerDaoImpl cusDao;
      
	@BeforeEach
	protected void setUp() throws Exception {
		cusDao = new CustomerDaoImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		cusDao = null;
	}

	@Test
	public void testCustomerDaoImpl() {
		 assertTrue(cusDao instanceof CustomerDaoImpl);
	}
	
	@Test
	public void testAddCustomer() {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cusDao.beginTransaction();
		Customer c=cusDao.addCustomer(cus);
		cusDao.commitTransaction();
		assertEquals(c.getCustomerName(),"ragav");
	}

	@Test
	public void testUpdateCustomer() throws CustomerIdNotFoundException {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cusDao.beginTransaction();
		cus = cusDao.addCustomer(cus);
		cusDao.commitTransaction();
		
		cus.setCustomerAddress("chennai");
		
		cusDao.beginTransaction();
		cusDao.updateCustomer(cus);
		cusDao.commitTransaction();
		
		assertEquals(cus.getCustomerAddress(), "chennai");
	}
	
	@Test
	public void testdeleteCustomer() throws CustomerIdNotFoundException {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cusDao.beginTransaction();
		cus = cusDao.addCustomer(cus);
		cus = cusDao.deleteCustomer(cus.getCustomerId());
		cusDao.commitTransaction();
		assertNull(cus);
	}
	
	@Test
	public void testViewCustomer() throws CustomerIdNotFoundException {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cusDao.beginTransaction();
		cus = cusDao.addCustomer(cus);
		cusDao.commitTransaction();
		cus = cusDao.viewCustomer(cus.getCustomerId());
		assertEquals(cus.getCustomerName(), "ragav");
	}

	@Test
	public void testViewCustomersList() {
		List<Customer> cusList = cusDao.viewCustomersList();
		assertNotNull(cusList);
	}

}

