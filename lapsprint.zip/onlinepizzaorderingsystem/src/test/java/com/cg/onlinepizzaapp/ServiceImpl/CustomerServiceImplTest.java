package com.cg.onlinepizzaapp.ServiceImpl;

import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.onlinepizzaapp.entity.Customer;

import junit.framework.TestCase;

class CustomerServiceImplTest extends TestCase {
	
	CustomerServiceImpl service;

	@BeforeEach
	protected void setUp() throws Exception {
	  service = new CustomerServiceImpl();
	}

	@AfterEach
	protected void tearDown() throws Exception {
		service = null;
	}

	@Test
	void testCustomerServiceImpl() {
		assertTrue(service instanceof CustomerServiceImpl);
	}

	@Test
	void testAddCustomer() {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cus = service.addCustomer(cus);
		assertEquals(cus.getCustomerName(), "ragav");
	}

	@Test
	void testUpdateCustomer() {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		service.addCustomer(cus);
		cus.setCustomerAddress("chennai");
		cus = service.updateCustomer(cus);
		assertEquals(cus.getCustomerAddress(), "chennai"); 
	}

	@Test
	void testDeleteCustomer() {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cus =service.deleteCustomer(cus.getCustomerId());
		assertNull(cus);
	}

	@Test
	void testViewCustomer() {
		Customer cus = new Customer("ragav",891889065,"ragav@gmail.com","Tirupur","ragav","ragav123");
		cus = service.addCustomer(cus);
		Customer docs = service.viewCustomer(cus.getCustomerId());
		assertEquals(docs.getCustomerName(), "ragav");
	}

	@Test
	void testViewCustomersList() {
		List<Customer> cust = service.viewCustomersList();
		assertNotNull(cust);
	}

}
