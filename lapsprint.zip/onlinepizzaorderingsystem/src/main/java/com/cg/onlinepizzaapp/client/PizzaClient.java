package com.cg.onlinepizzaapp.client;

import java.util.*;

import com.cg.onlinepizzaapp.ServiceImpl.PizzaServiceImpl;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.service.PizzaService;

public class PizzaClient {

	public void pizzaMain() {

		Scanner scan = new Scanner(System.in);
		PizzaService service = new PizzaServiceImpl();
		int signout = 1;
		while (signout == 1) {
			System.out.println("Enter the option");
			System.out.println("1)ViewList");
			System.out.println("2)ViewPizzaListBySize");
			System.out.println("3)AddPizza(ADMIN)");
			System.out.println("4)DeletePizza(ADMIN)");
			System.out.println("5)ForBooking");
			System.out.println("6)Signout");

			int option = scan.nextInt();
			switch (option) {
			case 1:
				List<Pizza> list = service.viewPizzaList();
				for (Pizza pz : list) {
					System.out.println(pz);
				}
				break;
			case 2:
				System.out.println("Select 1(Large),2(Medium),3(small)");
				int size = scan.nextInt();
				if (size == 1) {
					List<Pizza> siz = service.viewPizza("Large");
					for (Pizza vw : siz)
						System.out.println(vw);
				}
				if (size == 2) {
					List<Pizza> siz = service.viewPizza("Medium");
					for (Pizza vw : siz)
						System.out.println(vw);
				}
				if (size == 3) {
					List<Pizza> siz = service.viewPizza("small");
					for (Pizza vw : siz)
						System.out.println(vw);
				}
				break;
			case 3:
				System.out.println("Enter the AdminPassword");
				String passwd = scan.next();
				if (passwd.equals("Admin@123")) {
					int addmore = 1;
					while (addmore == 1) {
						System.out.println("Enter the PizzaType");
						String typ = scan.next();
						System.out.println("Enter the PizzaName");
						String name = scan.next();
						System.out.println("Enter the PizzaDescription");
						String desc = scan.next();
						System.out.println("Enter the PizzaCost");
						double cost = scan.nextDouble();
						System.out.println("Enter the CostAfterCoupan");
						double coupan = scan.nextDouble();
						Pizza newPizz = new Pizza(typ, name, desc, cost, coupan);
						newPizz = service.addPizza(newPizz);
						System.out.println("SAVE PIZZAID" + newPizz.getPizzaId());
						System.out.println("If you want to add more press 1 or 0 to exit");
						addmore = scan.nextInt();
					}

				} else
					System.out.println("WrongPassword");
				break;
			case 4:
				System.out.println("Enter the AdminPassword");
				String pass = scan.next();
				if (pass.equals("Admin@123")) {
					int val = 1;
					while (val == 1) {
						System.out.println("Enter the ID of pizza to be deleted");
						int id = scan.nextInt();
						service.deletePizza(id);
						System.out.println("If you want to delete more press 1 or 0 to exit");
						val = scan.nextInt();
					}
				} else
					System.out.println("WrongPassword");
				break;
			case 5:
				System.out.println("\n\nWelcomeForBooking\n\n");
				int sum = 0;
				int book = 1;
				while (book == 1) {
					System.out.println("Enter the PizzaId");
					int pizzid = scan.nextInt();
					boolean id=false;
					List<Pizza> l = service.viewPizzaList();
					for (Pizza pz : l) {
						if (pz.getPizzaId() == pizzid) {
							System.out.println("Enter the PizzaQuantity");
							int qty = scan.nextInt();
							sum += qty * pz.getPizzaCost();
							id=true;
						}
                   if(!id)System.out.println("NoSuchId");
					}
					System.out.println("Checkout for totalBill press 0 or if you want to addPizza press 1");
					book = scan.nextInt();
				}
				System.out.println("Press 1 for add coupan or else 0");
				int opt = scan.nextInt();
				if (opt == 1) {
					CoupanAdmin coup = new CoupanAdmin();
					coup.Coupmain(sum);
				} else {
					System.out.println("TotalBill without Coupan= " + sum);
				    }
				break;
			case 6:
				System.out.println("Signing Out");
				signout = 0;
				break;
			default:
				System.out.println("Enter Valid Option");
				break;
			}
		}
	}

}
