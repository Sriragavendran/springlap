package com.cg.onlinepizzaapp.DaoImpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.onlinepizzaapp.dao.JPAUtil;
import com.cg.onlinepizzaapp.dao.PizzaDao;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.InvalidMinCostException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;

public class PizzaDaoImpl implements PizzaDao {
	private EntityManager entityManager;

	public PizzaDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	public Pizza findPizzaById(int id) {
		Pizza pizza = entityManager.find(Pizza.class, id);
		return pizza;
	}

	public Pizza addPizza(Pizza pizza) {
		entityManager.persist(pizza);
		return pizza;
	}

	public Pizza updatePizza(Pizza pizza) {
		entityManager.merge(pizza);
		return pizza;
	}

	public List<Pizza> viewPizzaList() {
		TypedQuery<Pizza> query = entityManager.createQuery("SELECT p FROM Pizza p", Pizza.class);
		List<Pizza> pizzaList = query.getResultList();
		return pizzaList;
	}

	public List<Pizza> viewPizzaList(String PizzaType) {
		TypedQuery<Pizza> query = entityManager.createQuery("SELECT p FROM Pizza p where p.pizzaType=:pizzaType",
				Pizza.class);
		query.setParameter("pizzaType", PizzaType);
		List<Pizza> pizzaList = query.getResultList();
		return pizzaList;
	}

	public List<Pizza> viewPizzaList(double minCost, double maxCost) throws InvalidMinCostException {
		if (minCost < 50)
			throw new InvalidMinCostException(minCost);
		TypedQuery<Pizza> query = entityManager.createQuery(
				"SELECT p FROM Pizza p where pizzaCost between :pizzaMinCost and :pizzaMaxcost", Pizza.class);
		query.setParameter("pizzaMinCost", minCost);
		query.setParameter("pizzaMaxcost", maxCost);
		List<Pizza> pizzaList = query.getResultList();
		return pizzaList;
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public Pizza deletePizza(Integer pizzaId) throws PizzaIdNotFoundException {
		Pizza cou = entityManager.find(Pizza.class, pizzaId);
		if (cou == null)
			throw new PizzaIdNotFoundException(pizzaId);
		entityManager.remove(cou);
		cou = null;
		return cou;
	}

	@Override
	public Pizza viewPizza(Integer PizzaId) throws PizzaIdNotFoundException {

		return entityManager.find(Pizza.class, PizzaId);
	}

}
