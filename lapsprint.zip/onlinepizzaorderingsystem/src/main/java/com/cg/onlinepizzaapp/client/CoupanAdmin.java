package com.cg.onlinepizzaapp.client;

import java.util.List;
import java.util.Scanner;

import com.cg.onlinepizzaapp.entity.Coupan;
import com.cg.onlinepizzaapp.service.CoupanService;
import com.cg.onlinepizzaapp.ServiceImpl.CoupanServiceImpl;

public class CoupanAdmin {

	public void Coupmain(int sum) {
		CoupanService service = new CoupanServiceImpl();
		Coupan coupan = new Coupan();
		int coupanId;
		String coupanName;
		String coupanType;
		String coupanDescription;
		int coupanPizzaId;

		int temp = 0;
		while (temp == 0) {
			Scanner s = new Scanner(System.in);
			System.out.println("\n");
			System.out.println("****Coupan Service****");
			System.out.println("1.Add Coupan(ADMIN)");
			System.out.println("2.Delete Coupan(ADMIN)");
			System.out.println("3.View Coupans");
			System.out.println("4.SelectCoupan");
			System.out.println("5.ExitCoupanPage");
			System.out.println("Enter choice:");
			int choice = s.nextInt();

			switch (choice) {
			case 1:
				System.out.println("Enter the AdminPassword");
				String passwd = s.next();
				if (passwd.equals("Admin@123")) {
					//System.out.println("Enter Coupan Id:");
					//coupanId = s.nextInt();
					System.out.println("Enter Coupan Name:");
					coupanName = s.next();
					System.out.println("Enter Coupan Type:");
					coupanType = s.next();
					System.out.println("Enter Coupan Description:");
					coupanDescription = s.next();
					//System.out.println("Enter Coupan Pizza Id:");
					//coupanPizzaId = s.nextInt();

					//coupan.setCoupanId(coupanId);
					coupan.setCoupanName(coupanName);
					coupan.setCoupanType(coupanType);
					coupan.setCoupanDescription(coupanDescription);
					//coupan.setCoupanPizzaId(coupanPizzaId);
					service.addCoupans(coupan);

					System.out.println("Added Successfully");
				} else
					System.out.println("Wrong Password");
				break;

			case 2:
				System.out.println("Enter the AdminPassword");
				String pass = s.next();
				if (pass.equals("Admin@123")) {
					System.out.println("Enter Coupan Id to Delete");
					coupanId = s.nextInt();

					service.deleteCoupans(coupanId);
					System.out.println("Deleted Successfully");
				} else
					System.out.println("WrongPassword");

				break;

			case 3:
				List<Coupan> list = service.viewCoupans();
				for (Coupan l : list)
					System.out.println(l);

				break;
			case 4:
				System.out.println("Enter the CoupanId");
				int coupid = s.nextInt();
				boolean coupanid=false;
				List<Coupan> chk = service.viewCoupans();
				for (Coupan cou : chk) {
					if (cou.getCoupanId() == coupid) {
						coupanid=true;
						if (cou.getCoupanName().equalsIgnoreCase("ExtraFifty"))
							sum = sum / 2;
						if (cou.getCoupanName().equalsIgnoreCase("ExtraTwenty"))
							sum -= sum * (20 / 100);
						if (cou.getCoupanName().equalsIgnoreCase("ExtraTen"))
							sum -= sum * (10 / 100);
					}
				}if(!coupanid) {System.out.println("NoSuchCoupanID"); temp=1;}
				else {System.out.println("TotalBill after Coupan Discount= " + sum);
				return;}
				break;
			case 5:
				temp = 1;
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		}

	}

}
