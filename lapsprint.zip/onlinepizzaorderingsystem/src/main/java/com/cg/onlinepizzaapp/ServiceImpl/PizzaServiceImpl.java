package com.cg.onlinepizzaapp.ServiceImpl;

import java.util.List;

import com.cg.onlinepizzaapp.DaoImpl.PizzaDaoImpl;
import com.cg.onlinepizzaapp.dao.PizzaDao;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.InvalidMinCostException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;
import com.cg.onlinepizzaapp.service.PizzaService;

public class PizzaServiceImpl implements PizzaService {
	private PizzaDao dao;

	public PizzaServiceImpl() {
		dao = new PizzaDaoImpl();
	}

	@Override
	public Pizza addPizza(Pizza pizza) {
		dao.beginTransaction();
		dao.addPizza(pizza);
		dao.commitTransaction();
		return pizza;
	}

	public Pizza updatePizza(Pizza pizza) {
		dao.beginTransaction();
		dao.updatePizza(pizza);
		dao.commitTransaction();
		return pizza;
	}

	public Pizza deletePizza(int pizzaId) {
		Pizza piz = null;
		dao.beginTransaction();

		try {
			piz = dao.deletePizza(pizzaId);

			dao.deletePizza(pizzaId);
		} catch (PizzaIdNotFoundException e) {
			System.out.println(e);
		}

		dao.commitTransaction();

		return piz;
	}

	public List<Pizza> viewPizzaList() {

		List<Pizza> pizzaList = dao.viewPizzaList();

		return pizzaList;
	}

//
	public List<Pizza> viewPizza(String pizzaType) {
		List<Pizza> pizzaList = dao.viewPizzaList(pizzaType);
		return pizzaList;
	}

	

	@Override
	public Pizza viewPizza(int pizzaId) throws PizzaIdNotFoundException {

		return dao.viewPizza(pizzaId);
	}

	@Override
	public List<Pizza> viewPizzaList(double minCost, double maxCost) throws InvalidMinCostException {

		return dao.viewPizzaList(minCost, maxCost);
	}
}
