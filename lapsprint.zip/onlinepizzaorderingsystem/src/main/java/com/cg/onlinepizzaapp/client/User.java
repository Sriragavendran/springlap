package com.cg.onlinepizzaapp.client;

import java.util.*;

import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.exceptions.CustomerIdNotFoundException;
import com.cg.onlinepizzaapp.service.CustomerService;
import com.cg.onlinepizzaapp.ServiceImpl.CustomerServiceImpl;

public class User {
	static Scanner scan = new Scanner(System.in);
	static CustomerService service = new CustomerServiceImpl();
	
	public static void addNewUser() {
		List<Customer> list = service.viewCustomersList();

		System.out.println("Start entering the below details");
		System.out.println("Enter the customerName");
		String customerName = scan.next();
		System.out.println("Enter the mobile number");
		long customerMobile = scan.nextLong();
		String s = String.valueOf(customerMobile);
		Verification verify = new Verification();
		boolean mobile = verify.checkMobileNumber(s, list);// verification of mobile number
		while (!mobile) {
			s = scan.next();
			customerMobile=Long.parseLong(s);
			mobile = verify.checkMobileNumber(s, list);// verification of mobile number
		}
		System.out.println("Enter the email id");
		String customerEmail = scan.next();
		boolean email = verify.checkEmail(customerEmail, list);// verification of Email
		while (!email) {
			customerEmail = scan.next();
			email = verify.checkEmail(customerEmail, list);// verification of Email
		}
		System.out.println("Enter the Address");
		String customerAddress = scan.next();
		System.out.println("Enter the username (Minimum nameLength 4-6)");
		String userName = scan.next();
		String check = "[a-zA-Z]{4,6}";
		
		while (!userName.matches(check)) {
			System.out.println("\nInvalid Try newUserName\n");
			userName = scan.next();
		}

		System.out.println(
				"Enter the password(include atleast 1 specialCharacter and 1 number and length should be 8-20)");
		String password = scan.next();

		String passcheck = "(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,15}";
		while (!password.matches(passcheck)) {
			System.out.println("Password not matches the Constrain");
			System.out.println(
					"Enter the password(include atleast 1 specialCharacter and 1 number and length should be 8-20)");
			password = scan.next();
		}
		Customer customer = new Customer(customerName, customerMobile, customerEmail, customerAddress, userName,
				password);
		service.addCustomer(customer);
		System.out.println("\n\nSave your customer Id \n" + customer.getCustomerId());
		System.out.println("Register Completed");
	}
	public static void signIn() throws CustomerIdNotFoundException{
		System.out.println("Enter the customerId");
		int customerId = scan.nextInt();
		System.out.println("Enter the username");
		String e_userName = scan.next();
		System.out.println("Enter the password");
		String e_password = scan.next();

		try {
			Customer customerLogin = service.viewCustomer(customerId);

			if (customerLogin.getUserName().equals(e_userName)
					&& customerLogin.getPassword().equals(e_password)) {
				System.out.println("Login SuccessFul\n\n PizzaPage\n");
			PizzaClient obj=new PizzaClient();
			obj.pizzaMain();
			} else {
				System.out.println("InvalidUserId or name or password");
			}
		} catch (Exception e) {
			throw new CustomerIdNotFoundException("Not registered please create an account");
		}
	}
	public static void forgotPassword()
	{
		System.out.println("Enter Your UniqueId");
		int passResetId=scan.nextInt();
		Customer passReset= service.viewCustomer(passResetId);
		
		System.out.println(passReset.getPassword());
		
		//service.updateCustomer(passReset);
		
	}
	public static void main(String[] args) throws CustomerIdNotFoundException {
		//Scanner scan = new Scanner(System.in);
		
		boolean restart = true;
		while (restart) {
			System.out.println("Select the option");
			System.out.println("1)New User Registration");
			System.out.println("2)Sign in(Existing user)");
			System.out.println("3)Forgot Password");
			System.out.println("4)ViewCustomers(ADMIN)");
			System.out.println("5)DeleteCustomer(ADMIN)");
			System.out.println("6)sign out");
			int option = scan.nextInt();
			switch (option) {
			case 1:
			 addNewUser();
				break;
			case 2:
				signIn();
				break;
			case 3 :
				forgotPassword();
				break;
			case 4:
				System.out.println("Enter the AdminPassword");
				String pass = scan.next();
				if (pass.equals("Admin@123")) {
				List<Customer> list=service.viewCustomersList();
				for(Customer obj:list){
					System.out.print(obj.getCustomerId()+" ");
					System.out.print(obj.getCustomerName()+" ");
					System.out.print(obj.getCustomerEmail()+" ");
					System.out.print(obj.getCustomerAddress()+" ");
					System.out.print(obj.getUserName()+" \n");
				}
				}else System.out.println("WrongPassword");
				break;
			case 5:
				System.out.println("Enter the AdminPassword");
				String passwd = scan.next();
				if (passwd.equals("Admin@123")) {
				System.out.println("Enter the CustomerId to be deleted");
				int deltId=scan.nextInt();
				service.deleteCustomer(deltId);
				}
				break;
			case 6:
				System.out.println("Thank you for using our application");
				restart = false;
				break;
			}
			
			}
			System.out.println("Do you want to continue? type yes/no");
			String process = scan.next();
			if (process.equalsIgnoreCase(process))
				restart = true;
			else
				restart=false;
			
				}
		}
		
	

