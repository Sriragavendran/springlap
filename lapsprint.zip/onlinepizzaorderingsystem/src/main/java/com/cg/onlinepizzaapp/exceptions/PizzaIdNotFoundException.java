package com.cg.onlinepizzaapp.exceptions;

public class PizzaIdNotFoundException extends Exception {
	public PizzaIdNotFoundException(int pizzaId) {
		// TODO Auto-generated constructor stub
		System.out.println(pizzaId);
	}

	public PizzaIdNotFoundException(String message) {
		super(message);
	}
}
