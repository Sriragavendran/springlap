package com.cg.onlinepizzaapp.ServiceImpl;

import java.time.LocalDate;
import java.util.List;

import com.cg.onlinepizzaapp.DaoImpl.CustomerDaoImpl;
import com.cg.onlinepizzaapp.DaoImpl.IPizzaOrderDaoImpl;
import com.cg.onlinepizzaapp.dao.IPizzaOrderDao;
import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.entity.PizzaOrder;
import com.cg.onlinepizzaapp.service.CustomerService;
import com.cg.onlinepizzaapp.service.IPizzaOrderService;

public class IPizzaOrderServiceImpl implements IPizzaOrderService {

	private IPizzaOrderDao dao;

	public IPizzaOrderServiceImpl() {
		dao = new IPizzaOrderDaoImpl();
	}

	@Override
	public void bookPizzaOrder(PizzaOrder order) {
		dao.beginTransaction();
		dao.bookPizzaOrder(order);
		dao.commitTransaction();		
	}

	@Override
	public void updatePizzaOrder(PizzaOrder order) {
		dao.beginTransaction();
		dao.updatePizzaOrder(order);
		dao.commitTransaction();
	}

	@Override
	public void cancelPizzaOrder(Integer bookingOrderId) {
		dao.beginTransaction();
		dao.cancelPizzaOrder(bookingOrderId);
		dao.commitTransaction();
	}

	@Override
	public PizzaOrder viewPizzaOrder(Integer bookingOrderId) {
		PizzaOrder order = dao.viewPizzaOrder(bookingOrderId);
		return order;
	}

	@Override
	public List<PizzaOrder> viewOrdersList(PizzaOrder order) {
		List<PizzaOrder> pizzaList= dao.viewOrdersList(order);
		return pizzaList;
	}

	@Override
	public List<PizzaOrder> viewOrdersList(LocalDate date) {
		List<PizzaOrder> pizzaList= dao.viewOrdersList(date);
		return pizzaList;
}

	//s@Override
	public List<PizzaOrder> calculateTotal(String size, Integer quantity) {
		List<PizzaOrder> pizzaList= dao.calculateTotal(size,quantity);
		return pizzaList;
	}

}	
		