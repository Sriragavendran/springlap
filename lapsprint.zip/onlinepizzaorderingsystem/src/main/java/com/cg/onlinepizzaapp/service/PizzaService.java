package com.cg.onlinepizzaapp.service;

import java.util.List;

import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.exceptions.InvalidMinCostException;
import com.cg.onlinepizzaapp.exceptions.PizzaIdNotFoundException;

public interface PizzaService {

	Pizza addPizza(Pizza pizza);

	Pizza updatePizza(Pizza pizza);

	Pizza deletePizza(int pizza);

	List<Pizza> viewPizzaList();

	 Pizza viewPizza(int pizzaId) throws PizzaIdNotFoundException;

	List<Pizza> viewPizzaList(double minCost, double maxCost)throws InvalidMinCostException ;

	List<Pizza> viewPizza(String pizzaType);

}
