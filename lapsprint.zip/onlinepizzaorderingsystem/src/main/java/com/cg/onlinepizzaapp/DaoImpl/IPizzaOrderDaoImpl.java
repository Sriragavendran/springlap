package com.cg.onlinepizzaapp.DaoImpl;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.onlinepizzaapp.dao.JPAUtil;
import com.cg.onlinepizzaapp.dao.IPizzaOrderDao;
import com.cg.onlinepizzaapp.entity.Customer;
import com.cg.onlinepizzaapp.entity.Pizza;
import com.cg.onlinepizzaapp.entity.PizzaOrder;

public class IPizzaOrderDaoImpl  implements IPizzaOrderDao{
		private EntityManager entityManager;

		@Override
		public PizzaOrder bookPizzaOrder(PizzaOrder order) {
			entityManager.persist(order);
			return order;	
			
		}

		@Override
		public void updatePizzaOrder(PizzaOrder order) {
			entityManager.merge(order);
			
		}

		@Override
		public void cancelPizzaOrder(Integer bookingOrderId) {
			entityManager.remove(bookingOrderId);
			
		}
		
		@Override
		public PizzaOrder viewPizzaOrder(Integer bookingOrderId) {
			PizzaOrder order = entityManager.find(PizzaOrder.class, bookingOrderId);
			return order;
		}
		
		@Override
		public List<PizzaOrder> viewOrdersList(PizzaOrder order) {
			TypedQuery<PizzaOrder> query=entityManager.createQuery("SELECT p FROM PizzaOrder p", PizzaOrder.class);
			List<PizzaOrder> pizzaList = query.getResultList();
			return pizzaList;
		}

		@Override
		public List<PizzaOrder> viewOrdersList(LocalDate date) {
			TypedQuery<PizzaOrder> query= entityManager.createQuery("SELECT p FROM PizzaOrder p where date=date",PizzaOrder.class);
			List<PizzaOrder> pizzaList=query.getResultList();
			return pizzaList;
		}

		@Override
		public List<PizzaOrder> calculateTotal(String size, Integer quantity) {
			TypedQuery<PizzaOrder> query=entityManager.createQuery("SELECT p FROM PizzaOrder p", PizzaOrder.class);
			List<PizzaOrder> pizzaList = query.getResultList();
			return pizzaList;
			}

		@Override
		public void beginTransaction() {
			entityManager.getTransaction().begin();	
		}

		@Override
		public void commitTransaction() {
			entityManager.getTransaction().commit();
			
		}
}	